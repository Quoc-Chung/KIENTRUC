#include<bits/stdc++.h>
using namespace std;

void Merge(int A[], int left, int mid, int right)
{
	int i = left, j = mid + 1;  //Phan tu trai nhat cua hai mang con
	int n = right - left + 1;	//So phan tu cua A	
	int B[n];					//Mang luu ket qua trung gian
	
    for (int k = 0; k < n; k++)
        if (j > right) {		//Neu het mang con ben phai
           B[k] = A[i]; 
		   i++;
        } else if (i > mid) { //Neu het mang con ben trai
           B[k] = A[j];
		   j++;
        } else if (A[i] < A[j]) { //Neu phan tu cua mang trai nho hon phan tu cua mang phai
           B[k] = A[i];
		   i++;
        } else {				//Neu phan tu cua mang phai nho hon phan tu cua mang trai
           B[k] = A[j];
		   j++;
		}
    
	for (int k = 0; k < n; k++) //Chuyen cac phan tu sang mang chinh
		A[left + k] = B[k];
}

// left, right la bien trai va bien phai cua mang
void MergeSort(int A[], int left, int right)
{
	if (right > left)
	{
		int mid = (left + right) / 2; // Phan tu o giua
		MergeSort(A, left, mid); // Goi de quy mang con ben trai
		MergeSort(A, mid + 1, right); // Goi de quy mang con ben phai
		Merge(A, left, mid, right); // Goi ham so sanh hai mang con
	}
}

int main()
{
	int A[10], n = 10;
	for (int i = 0; i < n; i++)
	{
		cout << "Nhap so " << i + 1 << ": ";
		cin >> A[i];
	}

	MergeSort(A, 0, n - 1);
	for (int i = 0; i < n; i++)
		cout << A[i] << " ";
	return 0;
}

