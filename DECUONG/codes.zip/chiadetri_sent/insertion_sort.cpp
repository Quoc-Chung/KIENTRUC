#include<bits/stdc++.h>
using namespace std;

void insertion_sort(int a[], int n) {
   int i, j, v;
   for(i = 2; i <= n; i++) {
        v = a[i]; 
        j = i;
        while(a[j - 1] > v) {
             a[j] = a[j - 1];
             j--;
        }
        a[j] = v;
    }
}

int main()
{
	int a[] = {0, 2, 6, 5, 2, 7, 1, 9, 8};
	int n = 8;
	
	insertion_sort(a, n);
	for (int i = 1; i <= n; i++)
		cout<<a[i]<<" ";
	
	return 0;
}


