#include<bits/stdc++.h>
using namespace std;

void quickSort(int Data[], int l , int r)
{
	// If the first index less than or equal to the last index
	if (l <= r)
	{
		// Create a Key/Pivot Element
		int key = Data[(l+r)/2];

		// Create temp Variables to loop through array
		int i = l;
		int j = r;

		while (i <= j)
		{
			while (Data[i] < key)
				i++;
			while (Data[j] > key)
				j--;

			if (i <= j)
			{
				swap(Data[i], Data[j]);
				i++;
				j--;
			}
		}

		// Recursion to the smaller partition in the array after sorted above
		if (l < j) quickSort(Data, l, j);
		if (r > i) quickSort(Data, i, r);
	}
}

void printArray(int Data[], int size)  
{  
    int i;
    for (i = 0; i < size; i++)
        cout << Data[i] << " ";
    cout << endl;
}

long getMilliCount(){
	timeb tb;
	ftime(&tb);
	long nCount = tb.millitm + (tb.time & 0xfffff) * 1000;
	return nCount;
}

long getMilliSpan(long nTimeStart){
	long nSpan = getMilliCount() - nTimeStart;
	if(nSpan < 0)
		nSpan += 0x100000 * 1000;
	return nSpan;
}

int main()  
{  
    //int arr[] = {10, 7, 8, 9, 1, 5};
    int arr[500000];
	string line;
	ifstream myfile ("example.txt");
	if (myfile.is_open())
	{
		long i = 0;
	    while (getline (myfile,line))
	    {
	    	arr[i] = stol(line, nullptr, 10);
	    	i++;
	    }
	    myfile.close();
	}
	    
    int n = sizeof(arr) / sizeof(arr[0]);
    long start = getMilliCount();
    quickSort(arr, 0, n - 1);
    long milliSecondsElapsed = getMilliSpan(start);
    cout << "Array sorted in "<<milliSecondsElapsed<<" milliseconds!"<<endl;
    //printArray(arr, n);
    
    return 0;
}


