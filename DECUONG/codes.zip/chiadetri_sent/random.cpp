#include<bits/stdc++.h>
using namespace std;
 
int random(int minN, int maxN){
    return minN + rand() % (maxN + 1 - minN);
}
 
int main(){
    srand((int)time(0));
  	ofstream myfile;
  	myfile.open ("example.txt");  
    int r;
    for(int i = 0; i < 500000; ++i){
        r = random(1,500000);
        myfile << r << endl;
    }
    myfile.close();
    //cin.get();
    return 0;
}

