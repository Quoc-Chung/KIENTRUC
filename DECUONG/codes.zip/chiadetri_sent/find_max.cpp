#include<bits/stdc++.h>
using namespace std;

int FindMax(int A[], int low, int high) {
    if (low == high)	{ //Neu chi so dau va cuoi bang nhau
        int max = A[low];
        return max; 	//mang can mot phan tu
    } else {
        int mid = (low + high) / 2;
        int x= FindMax(A, low, mid);
        int y = FindMax(A, mid + 1, high);
        //Tra lai phan tu lon nhat tu hai mang con
        if (x > y) return x;
        else return y;
    }
}

int main()
{
	int A[] = {5, 6, 100, 9, 501, 4, 24, 50};
	int n = 8;
	
	int max_no = FindMax(A, 0, n);
	
	cout<<"Mang so nguyen: ";
	for (int i = 0; i < n; i++)
		cout<<A[i]<<" ";
	
	cout<<endl<<"Phan tu lon nhat la: "<<max_no;
	
	return 0;
}


