#include <iostream>
using namespace std;
//De quy chay voi so n nho
long Fibonacci(int n)
{
	if (n < 2)
		return n;
	else return Fibonacci(n - 1) + Fibonacci(n - 2);
}
int main()
{
    int n;
    cout << "nhap n: ";
    cin >> n;
    cout << "So Fibonacci thu " << n << " la: " << Fibonacci(n);
    return 0;
}
