#include<bits/stdc++.h>
using namespace std;

long power(int a, int n) {
    long x;
    if (n == 1)
        return a;
    else {
        x = power(a, n / 2);	//chia nguyen
        if (n % 2 == 0)  		//n chan
            return x * x;
        else 					//n le
            return x * x * a;
    }
}

int main()
{
	int a, n;
	cout<<"Nhap co so a: ";
	cin>>a;
	cout<<"Nhap so mu n: ";
	cin>>n;
	
	long gt = power(a, n);
	
	cout<<"Luy thua cua "<<a<<" mu "<<n<<" la: "<<gt;
	
	return 0;
}


