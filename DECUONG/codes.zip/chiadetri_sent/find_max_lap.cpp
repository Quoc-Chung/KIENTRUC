#include<bits/stdc++.h>
using namespace std;

int FindMax(int A[], int n)
{
    int max = A[0];
    for (int i = 1; i < n; i++)
        if (A[i] > max) max = A[i];
    
    return max;
}

int main()
{
	int A[] = {5, 6, 101, 9, 501, 4, 24, 50};
	int n = 8;
	
	int max_no = FindMax(A, n);
	
	cout<<"Mang so nguyen: ";
	for (int i = 0; i < n; i++)
		cout<<A[i]<<" ";
	
	cout<<endl<<"Phan tu lon nhat la: "<<max_no;
	
	return 0;
}


