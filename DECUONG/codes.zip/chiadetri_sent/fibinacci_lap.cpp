#include <iostream>
using namespace std;
long Fibonacci(int n)
{
    if (n < 2) return n;
    long n1 = 1, n2 = 0; // luu co so vao cac bien
    for (int i = 2; i < n; i++) {
        long n0 = n1 + n2;
        n2 = n1;
        n1 = n0;
    }
    return n1 + n2;
}
int main()
{
    int n;
    cout << "nhap n: ";
    cin >> n;
    cout << "So Fibonacci thu " << n << " la: " << Fibonacci(n);
    
    return 0;
}
