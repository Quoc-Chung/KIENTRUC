#include<bits/stdc++.h>
using namespace std;

int gcd(int a, int b) {
    int r;
    while(b != 0) {
        r = a % b;  //Phep chia du
        a = b;
        b = r;
    }
    return a;
}

int main()
{
	int a, b;
	cout<<"Nhap so a: ";cin>>a;
	cout<<"Nhap so b: ";cin>>b;
	int c = gcd(a, b);
	cout<<"Uoc so chung lon nhat cua "<<a<<" va "<<b<<" la: "<<c;
}


