#include<bits/stdc++.h>
using namespace std;

long power(int a, int n) {
    long x = a;
    if (n == 1)
        return a;
    else {
		for (int i = 1; i < n; i++)
			x = x * a;
    }
    
    return x;
}

int main()
{
	int a, n;
	cout<<"Nhap co so a: ";
	cin>>a;
	cout<<"Nhap so mu n: ";
	cin>>n;
	
	long gt = power(a, n);
	
	cout<<"Luy thua cua "<<a<<" mu "<<n<<" la: "<<gt;
	
	return 0;
}


